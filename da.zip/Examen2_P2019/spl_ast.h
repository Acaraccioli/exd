#ifndef _AST_H
#define _AST_H

#include <iostream>
#include <string>
#include <memory>
#include <vector>
#include <unordered_map>
using namespace std;
class Expr;
class Stmt;
using PExpr = unique_ptr<Expr>;
using ExprList = vector<PExpr>; //CAMBIIO
using PStmt = unique_ptr<Stmt>;
using StmtList = vector<PStmt>;

class Context {
public:
    Context(){};
    unordered_map<string,int> vars;
};


class ASTNode {
public:
    ASTNode() {}
    virtual ~ASTNode() {}
};

class Expr: public ASTNode {
public:
    Expr(){};
    virtual string getType() = 0;
    virtual int eval(Context& ctx) = 0;
};

class AddExpr: public Expr {
public:
    AddExpr(PExpr expr1, PExpr expr2) : expr1(move(expr1)), expr2(move(expr2)){};
    int eval(Context& ctx){
        int ex1 = expr1->eval(ctx);
        int ex2 = expr2->eval(ctx);
        int res = ex1 + ex2;
        return res;
    };
    string getType(){return "Num";};
    PExpr expr1, expr2;
};

class SubExpr: public Expr {
public:
    SubExpr(PExpr expr1, PExpr expr2) : expr1(move(expr1)), expr2(move(expr2)){};
    int eval(Context& ctx){
        int ex1 = expr1->eval(ctx);
        int ex2 = expr2->eval(ctx);
        int res = ex1 - ex2;
        return res;
    };
    string getType(){return "Num";};
    PExpr expr1, expr2;
};

class MulExpr: public Expr {
public:
    MulExpr(PExpr expr1, PExpr expr2) : expr1(move(expr1)), expr2(move(expr2)){};

    int eval(Context& ctx){
        int ex1 = expr1->eval(ctx);
        int ex2 = expr2->eval(ctx);
        int res = ex1 * ex2;
        return res;
    };
    string getType(){return "Num";};
    PExpr expr1, expr2;
};

class DivExpr: public Expr {
public:
    DivExpr(PExpr expr1, PExpr expr2) : expr1(move(expr1)), expr2(move(expr2)){};

    int eval(Context& ctx){
        int ex1 = expr1->eval(ctx);
        int ex2 = expr2->eval(ctx);
        int res = ex1 / ex2;
        return res;
    };
    string getType(){return "Num";};
    PExpr expr1, expr2;
};

class IdExpr: public Expr {
public:
    IdExpr(string name) : name(name){};
    int eval(Context& ctx){
        return ctx.vars.operator[](name);
    };
    string getType(){return "Id";};
    string name;
};

class NumExpr: public Expr {
public:
    NumExpr(int value) : value(value){};
    int eval(Context& ctx){return value;};
    string getType(){return "Num";};
    int value;
};

class Stmt: public ASTNode {
public:
    Stmt(){};
    virtual void exec(Context& ctx) = 0;
};

class AssignStmt : public Stmt {
public:
    AssignStmt(string id, PExpr val): id(id),val(move(val)){};
    void exec(Context& ctx){
        int valor = val->eval(ctx);
        cout << "VALUE: " << valor << endl;
        ctx.vars.emplace(id,valor);
    };
    PExpr val;
    string id;
};

class IfStmt : public Stmt {
public:
    IfStmt(PExpr e, PStmt st1, PStmt st2):e(move(e)),st1(move(st1)),st2(move(st2)){};
    void exec(Context& ctx){
        int valor = e->eval(ctx);
	if(valor)
		st1->exec(ctx);
	st2->exec(ctx);
    };
    PExpr e;
    PStmt st1, st2;
};

class BlockStmt: public Stmt {
public:
    BlockStmt(StmtList stmt_list): stmt_list(move(stmt_list)){};
    void exec(Context& ctx){
        //cout << "SIZE: " <<stmt_list.size() << endl;
        for(int a = 0; a < stmt_list.size(); a++){
            stmt = move(stmt_list.at(a));
            stmt->exec(ctx);
        }     
    };
    PStmt stmt;
    StmtList stmt_list;
};

/*
#define ASSIGN(id, e) (make_unique<AssignStmt>(id, e))
#define IF(e, st1, st2) (make_unique<IfStmt>(e, st1, st2))
#define BLOCK(l) (make_unique<BlockStmt>(move(l)))


*/
#endif
