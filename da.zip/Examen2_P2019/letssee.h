
#ifndef _AST_H
#define _AST_H
#include <iostream>
#include <memory>
#include <vector>
#include <unordered_map>
#include <string>

class Expr;
class Stmt;
using namespace std;
using ExprList= vector<PExpr>;
using PExpr= unique_ptr<Expr>;
using StmtList= vector<PStmt>;
using PStmt= unique_ptr< Stmt>;

class Context{
public:
Context(){};
unordered_map <string, int> vars;
};

class ASTNode{
public:
ASTNode(){};
virtual ~ASTNode(){};

};

class Expr: public ASTNode{
public:
Expr(){};
virtual string getType()=0;
virtual int eval(Context & ctx)=0;
};

class AddExpr : public Expr{
public: 
AddExpr(PExpr expr1, PExpr expr2): expr1(move(expr1)), expr2(move(expr2)){};
int eval(Context & ctx){

    int uno= expr1->eval(ctx);
    int dos=expr2->eval(ctx);
    int res =uno+dos;
    return res;
}
string getType(){return "Num";};
PExpr expr1, expr2;

};

class NumExpr: public Expr{
NumExpr(int val): val(val){};
int eval(Context & ctx)
{
    return val;
}
string getType(){return "Num";};
int val;

};

class IdExpr: public Expr{
public:
IdExpr(string name): name(name){};
int eval(Context & ctx)
{
    return ctx.vars.operator[](name);
}
string getType(){return "Id";};
string name;

};

class Stmt : public ASTNode{
    public:
Stmt(){};
virtual void exec(Context & ctx)=0;
};

class AssignStmt :  public Stmt{
AssignStmt (string name, PExpr val): name(name),val(move(val)){};
void Exec(Context ctx){
    int value= val->eval(ctx);
    ctx.vars.emplace(name,val);
}

string name;
PExpr val;
};

    
class IfStmt : public Stmt {
public:
    IfStmt(PExpr e, PStmt st1, PStmt sts): e(move(e)), st1(move(st1)), st2(move(st2)){};
    void exec(Context& ctx){
        int valor = e->eval(ctx);
	if(valor)
		st1->exec(ctx);
	st2->exec(ctx);
    };
    PExpr e;
    PStmt st1, st2;
};




#endif

